# -*- coding: utf-8 -*-
from odoo import fields, models


class SchoolClubs(models.Model):
    """school clubs"""
    _name = 'school.clubs'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Club Name')
    student_ids = fields.Many2many('school.students', string='Student')
    event_ids = fields.One2many('school.events','club_id', string='Event')
    event_count = fields.Integer(string='Event Count', compute='_compute_event_count')
    student_id = fields.Many2one('school.students', string='Student')

    def _compute_event_count(self):
        """it usd for total count of event ,itss used for smart button"""
        for rec in self:
            rec.event_count = len(rec.event_ids)

    def action_open_events(self):
        """ smart button in club form view"""
        return {
            'type': 'ir.actions.act_window',
            'name': 'Events',
            'res_model': 'school.events',
            'domain': [('club_id' ,'=' , self.id)],
            'view_mode': 'list,form',
            }



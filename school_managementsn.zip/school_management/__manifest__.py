# -*- coding: utf-8 -*-
{
    'name': "School Management",
    'version': "19.0.1.0.0",
    'license':"LGPL-3",
    'author': "Cybrosys Techno Solutions",
    'website': 'https://www.cybrosys.com',
    'category': 'Education',
    'summary': 'School Management',
    'description': """manage student,subject,department""",
    'sequence': 10,
    'application': True,
    'installable': True,
    'auto_install': True,
    'depends': ['base','mail', 'sale', 'contacts','website'],
    'data':[
        "security/school_management_groups.xml",
        "security/ir.model.access.csv",
        "security/school_student_record_rule.xml",

        "data/sequence_data.xml",
        "data/school_class_data.xml",
        "data/school_department_data.xml",
        "data/school_subject_data.xml",
        "data/ ir_cron_data.xml",
        "data/mail_template_data.xml",
        "data/action_user_creation_data.xml",

        "views/school_students_view.xml",
        "views/school_department_views.xml",
        "views/school_class_views.xml",
        "views/school_subject_views.xml",
        "views/school_year_views.xml",
        "views/school_clubs_views.xml",
        "views/sale_order_views.xml",
        "views/res_partner_views.xml",
        "views/school_leaves_views.xml",
        "views/school_exam_views.xml",
        "views/school_registerd_student_view.xml",
        "views/school_events_views.xml",

        "views/website_leave_create.xml",
        "views/website_student_register.xml",
        "views/website_student_leave.xml",
        "/home/cybrosys/odoo-19/custom/school_management/views/snippets/website_snippet.xml",



        "wizard/student_leave_wizard_views.xml",
        "wizard/school_club_data_views.xml",
        "wizard/student_information.xml",
        "wizard/student_leave_form_views.xml",
        "wizard/school_club_action_views.xml",
        "wizard/school_information_action.xml",
        "report/student_leave_report_views.xml",
        "report/student_leave_action.xml",

        "report/school_club_template.xml",
        "report/school_clubs_action.xml",
        "report/school_information_format.xml",
        "report/student_information_template.xml",
        "report/student_information_action.xml",


        "views/student_menu_views.xml",

    ],
    'assets': {
        'web.assets_frontend': [
            "school_management/static/src/xml/website_event_template_views.xml",
            "school_management/static/src/js/website_leave.js",

        ],
       'web.assets_backend': [
           "school_management/static/src/js/leave.js",

       ],

   },
}


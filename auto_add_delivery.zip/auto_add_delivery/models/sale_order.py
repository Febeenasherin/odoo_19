# -*- coding: utf-8 -*-
from odoo import fields, models


class SaleOrder(models.Model):
    """add status in sale module"""
    _inherit = 'sale.order'
    def action_confirm(self):
        self.ensure_one()
        produ =self.env['product.product'].search([('name' , '=', "Local delivery")],limit=1)
        if self.amount_untaxed < 1500:
            self.env['sale.order.line'].create({
                    'order_id': self.id,
                    'product_id': produ.id,})
        print ("pro",produ)
        return super().action_confirm()

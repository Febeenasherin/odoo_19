# -*- coding: utf-8 -*-
from odoo import fields, models


class SalesOrder(models.Model):
    _inherit = "sale.order"

    project_id = fields.Many2one('project.project', string="Project")

    def project_create(self):

        print(self)
        print(self.partner_id)

        if not self.project_id:
            self.project_id = self.env['project.project'].create({'name': self.name})
            print("project", self.project_id)

        for line in self.order_line:
            task_ids = self.project_id.task_ids
            main_task = task_ids.filtered(lambda task: task.name == f"Milestone {line.milestone}")
            print("task", main_task)
            if not main_task:
                main_task = task_ids.create({'name': f"Milestone {line.milestone}", 'project_id': self.project_id.id})

            # sub_task = self.env['project.task'].search([('project_id', '=', self.project_id.id),
            #                                         ('name', '=', f"Milestone{line.milestone}"),
            #
            #                                         ], limit=1)

            child_task_ids = main_task.child_ids
            child_task = child_task_ids.filtered(
                lambda task: task.name == f"Milestone {line.milestone} - {line.product_template_id.display_name}")
            if not child_task:
                child_task = self.env['project.task'].create(
                    {'name': f'Milestone {line.milestone} - {line.product_template_id.display_name}',
                     'project_id': self.project_id.id,
                     'parent_id': main_task.id, })

            # sub = self.env['project.task']
            # task.write({'parent_id' : [fields.Command.create({'name' : line.product_template_id.display_name,
            #                                  'project_id' : self.project_id.id ,
            #                                  ''
            #                                  }),]})

            # print("sub",task.child_ids)
            # print("pro",line.product_template_id.display_name)

        # return True

        # print(self.name)
        # print(project.name)
        # print(task)
        # return project,task

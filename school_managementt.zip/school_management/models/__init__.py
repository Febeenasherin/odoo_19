# -*- coding: utf-8 -*-
from . import school_students
from . import school_department
from . import school_class
from . import school_subjects
from . import school_year
from . import school_clubs
from . import school_events
from . import sale_order
from . import res_partner
from . import school_leaves
from . import school_exam
from . import school_exam_paper
